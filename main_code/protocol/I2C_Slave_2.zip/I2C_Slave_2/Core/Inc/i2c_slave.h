/*
 * i2c_slave.h
 *
 *  Created on: Apr 23, 2024
 *      Author: Administrator
 */

#ifndef INC_I2C_SLAVE_H_
#define INC_I2C_SLAVE_H_



#endif /* INC_I2C_SLAVE_H_ */
